# 2. Identify the Data Types Given the following variables: 
name = "Abdurrahman"    # str
age = 25                # int
height = 1.75           # float
is_student = True       # Boolean

# Write a program that prints the value and data type of each variable. 
# Expected concept: 
print(type(name)) 
print(type(age)) 
print(type(height)) 
print(type(is_student)) 