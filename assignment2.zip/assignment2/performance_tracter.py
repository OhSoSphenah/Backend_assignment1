# Initial Setup & Batch Count
count = int(input("How many student entries do you want to create? "))

# Empty dictionary to store student records
student_records = {}

# Dynamic Entry Loop
for i in range(count):
    print(f"\n--- Entry {i + 1} ---")

    name = input("Enter student name: ")
    score = float(input("Enter score (0-100): "))

    # Store student name and score
    student_records[name] = score


# Evaluation & Performance Analysis
print("\n========================================")
print("EVALUATION RESULTS")
print("========================================")

passed = 0
failed = 0

for name, score in student_records.items():

    if score >= 70:
        grade = "A"
        status = "Passed with Distinction"
        passed += 1

    elif score >= 50:
        grade = "B"
        status = "Passed"
        passed += 1

    else:
        grade = "F"
        status = "Needs Improvement"
        failed += 1

    print(f"- {name}: Score {score:.1f} | Grade {grade} | {status}")


# Class Summary
average_score = sum(student_records.values()) / count

print("========================================")
print("CLASS PERFORMANCE")
print("========================================")
print(f"Average Score: {average_score:.1f}")
print(f"Total Passed: {passed}")
print(f"Total Failed: {failed}")
