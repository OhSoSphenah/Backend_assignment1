# Part 5: Dictionaries 8. 
# Student Profile Create a dictionary containing information about a student: 
# Name 
# Age 
# Course 
# Level 
# Skills 
student_profile = {'Name': 'Sihle', 'Age': 24, 'Course': 'Backend', 'Level': 'Last Year', 'Skill':'Python'}
# Perform the following: 
# 1. Print the entire dictionary.  
for key, value in student_profile.items():
    print(f"{key}, {value}")

# 2. Print the student's name.  
print(student_profile['Name'])

# 3. Add a new key called email.  
student_profile['email'] = 'sihle@gmail.com'

# 4. Change the student's level.  
student_profile['Level'] = '1st Year'

# 5. Remove the age key.  
del student_profile['Age']

# 6. Print the final dictionary. 
print(student_profile)