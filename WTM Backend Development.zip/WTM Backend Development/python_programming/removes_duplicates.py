# Part 4: Sets 
# 6. Remove Duplicate Values Given the following list: 
numbers = [1, 2, 3, 4, 2, 5, 3, 6, 1] 

# Write a program to: 
# 1. Convert the list into a set.  
my_set = set(numbers)

# 2. Print the result.  
print(my_set)
# 3. Explain why some values disappeared.  
'''Sets cannot contain duplicate values. Any repeated items in your list will automatically be shrunk down to a single instance.'''