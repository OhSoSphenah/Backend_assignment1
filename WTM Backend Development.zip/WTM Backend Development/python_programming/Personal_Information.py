# 1. Personal Information 
# Write a Python program that stores and prints the following information about yourself: 
# • Name  
# • Age  
# • Height  
# • Whether you are a student (True or False)  
# Use appropriate Python data types for each value. 
# Example output: 
# Name: John 
# Age: 25 
# Height: 1.75 
# Student: True 

name = 'Sihle'
age = 24
hight = 1.68
is_student = True

print(f"Name: {name}")
print(f"Age: {age}")
print(f"Hight: {hight}")
print(f"Student: {is_student}")



