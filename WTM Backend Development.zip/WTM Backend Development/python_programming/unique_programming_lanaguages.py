# 7. Unique Programming Languages Given: 
languages =["Python", "Java", "Python", "C++", "JavaScript", "Python"]

# Convert the list into a set and print the unique programming languages. 
unique_languages = set(languages)
print(unique_languages)

# Then add "Django" to the set.
unique_languages.add("Django")
print(unique_languages)