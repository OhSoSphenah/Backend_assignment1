# Available inventory: Item Name -> Unit Price
catalog = {
    "laptop": 800,
    "mouse": 20,
    "keyboard": 50,
    "monitor": 150
}

# Running total
grand_total = 0

while True:
    item = input("Enter item to buy (or 'checkout' / 'exit'): ").lower()

    # Exit immediately without printing a receipt
    if item == "exit":
        print("--> Order cancelled. Goodbye!")
        break

    # Checkout
    elif item == "checkout":
        # Apply conditional discount
        if grand_total >= 500:
            discount_rate = 0.10
        elif grand_total >= 200:
            discount_rate = 0.05
        else:
            discount_rate = 0.00

        discount = grand_total * discount_rate
        final_total = grand_total - discount

        # Print receipt
        print("\nCHECKOUT RECEIPT")
        print("========================================")
        print(f"Subtotal: ${grand_total:.1f}")
        print(f"Discount: ${discount:.1f}")
        print(f"Final Total: ${final_total:.1f}")
        print("========================================")

        break

    # Check whether item exists in catalog
    elif item in catalog:
        price = catalog[item]
        grand_total += price
        print(f"--> Added {item} (${price}) to order.")

    # Invalid item
    else:
        print("--> [ERROR] Item not found in catalog. Try again.")
