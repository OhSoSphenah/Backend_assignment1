# 3. Favourite Foods Create a list containing at least 5 favourite foods. 
favourite_food = ['Burger', 'Pizza', 'Fried Chicken', 'Sausage', 'Cake']

# Perform the following operations: 
# 1. Print the entire list.  
print(favourite_food)

# 2. Print the first and last food.  
print(favourite_food[0])
print(favourite_food[-1])

# 3. Add one more food.  
favourite_food.append("Chocolate")
print(favourite_food)

# 4. Remove one food.  
favourite_food.pop(2)
print(favourite_food)

# 5. Change one food to another food.  
favourite_food[-1] = 'chocolate cake'

# 6. Print the final list.  
print(favourite_food)