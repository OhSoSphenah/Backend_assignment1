# Final Challenge         
# 9. Student Management Data Create a dictionary for 3 students. 
# Each student should have: 
# • Name  
# • Age  
# • Course  
# • A list of at least 3 skills  Example structure: 
# 1. student1:  
# a. name: John 
# b. age: 22 
# c. course: Backend Development, 
# d. skills: Python, HTML, Git 2. 
# student2: 
# a. name: Mary 
# b. age: 24 
# c. course: Data Analysis 
# d. skills: Excel, SQL, Python 
# Your program should print the information for all students. 
# Create a nested dictionary storing information for 3 students
students = {
    "student1": {
        "name": "John",
        "age": 22,
        "course": "Backend Development",
        "skills": ["Python", "HTML", "Git"]
    },
    "student2": {
        "name": "Mary",
        "age": 24,
        "course": "Data Analysis",
        "skills": ["Excel", "SQL", "Python"]
    },
    "student3": {
        "name": "Alex",
        "age": 21,
        "course": "UI/UX Design",
        "skills": ["Figma", "User Research", "Wireframing"]
    }
}

# Print the information for all students
for student_id, details in students.items():
    print(f"--- {student_id.upper()} ---")
    print(f"Name:   {details['name']}")
    print(f"Age:    {details['age']}")
    print(f"Course: {details['course']}")
    print(f"Skills: {', '.join(details['skills'])}\n")