# Part 3: Tuples 5. 
# Days of the Week Create a tuple containing the seven days of the week. 
week_days = ('Monday', 'Tuesday', 'Wednesday', 'Thursday','Friday', 'Saturday', 'Sunday')
# Your program should: 
# 1. Print the entire tuple.  
print(week_days)
# 2. Print the first day.  
print(week_days[0])
# 3. Print the last day.  
print(week_days[-1])
# 4. Attempt to change one of the values and explain what happens.  
week_days[0] = 'weekend' # tuples are immutable the dont maniculations of data in the tuples

# Question: Why is a tuple different from a list? 
'''Tuples are used for data that is standard or fixed like in the example above the days of the week cant be changed'''