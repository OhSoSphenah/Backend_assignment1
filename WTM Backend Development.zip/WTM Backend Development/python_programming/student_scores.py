# 4. Student Scores Given the following list: 

scores = [75, 80, 65, 90, 85] 
# Write a program to: 
# 1. Print all the scores.  
print(scores)

# 2. Print the highest score.  
highest_score = max(scores)
print(highest_score)

# 3. Print the lowest score.
lowest_score = min(scores)  
print(lowest_score)  

# 4. Add a new score of 95.  
scores.append(95)

# 5. Print the updated list.  
print(scores)